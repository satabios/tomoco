from model_compression import pruner

__all__ = [ "pruner"]
